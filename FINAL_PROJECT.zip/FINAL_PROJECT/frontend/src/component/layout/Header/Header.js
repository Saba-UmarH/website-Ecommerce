import React from "react";
import {ReactNavbar}  from "overlay-navbar";
import logo from "../../../images/logo.png";
import {BsSearch} from "react-icons/bs";
import {BsCart} from "react-icons/bs";
import {CgProfile} from "react-icons/cg";


// const options = {
//   burgerColorHover: "#eb4034",
//   logo,
//   logoWidth: "20vmax",
//   navColor1: "white",
//   logoHoverSize: "10px",
//   logoHoverColor: "#eb4034",
//   link1Text: "Home",
//   link2Text: "Products",
//   link3Text: "Contact",
//   link4Text: "About",
//   link1Url: "/",
//   link2Url: "/products",
//   link3Url: "/contact",
//   link4Url: "/about",
//   link1Size: "1.3vmax",
//   link1Color: "rgba(35, 35, 35,0.8)",
//   nav1justifyContent: "flex-end",
//   nav2justifyContent: "flex-end",
//   nav3justifyContent: "flex-start",
//   nav4justifyContent: "flex-start",
//   link1ColorHover: "#eb4034",
//   link1Margin: "1vmax",
//   profileIconUrl: "/login",
//   profileIconColor: "rgba(35, 35, 35,0.8)",
//   searchIconColor: "rgba(35, 35, 35,0.8)",
//   cartIconColor: "rgba(35, 35, 35,0.8)",
//   profileIconColorHover: "#eb4034",
//   searchIconColorHover: "#eb4034",
//   cartIconColorHover: "#eb4034",
//   cartIconMargin: "1vmax",
//   searchIcon:true,
//   SearchIconElement:{BsSearch},
//   searchIconUrl: "/search",
//   searchIconSize:"10vmax",
//   cartIcon:true,
//   cartIconElement:{BsCart},
//   cartIconUrl: "/cart",
//   cartIconSize:"10vmax",
  // profileIcon: true,
  // profileIconElement:{FaBeer},
  // profileIconSize:"10vmax",
// };

// const Header = () => {
//   return <ReactNavbar {...options} />;
// };

const Header = () => {
  return (
  <ReactNavbar 
  burgerColor="silver"
  burgerColorHover= "blue"
  logo={logo}
  logoWidth= "20vmax"
  navColor1= "white"
  logoHoverSize= "10px"
  logoHoverColor= "blue"
  link1Text= "Home"
  link2Text= "Products"
  link3Text= "Contact"
  link4Text= "About"
  link1Url= "/"
  link2Url= "/products"
  link3Url= "/contact"
  link4Url= "/about"
  link1Size= "2vmax"
  link1Color= "black"
  nav1justifyContent= "flex-end"
  nav2justifyContent= "flex-end"
  nav3justifyContent= "flex-start"
  nav4justifyContent= "flex-start"
  link1ColorHover= "blue"
  link1Margin= "1vmax"
  profileIconUrl= "/login"
  profileIconColor= "black"
  searchIconColor= "black"
  cartIconColor= "black"
  profileIconColorHover= "blue"
  searchIconColorHover = "blue"
  cartIconColorHover= "blue"
  cartIconMargin = "1vmax"
  searchIcon={true}
  SearchIconElement={BsSearch}
  searchIconUrl= "/search"
  searchIconSize="2vmax"
  cartIcon={true}
  CartIconElement={BsCart}
  cartIconUrl= "/cart"
  cartIconSize="2vmax"
  profileIcon= {true}
  ProfileIconElement={CgProfile}
  profileIconSize="2vmax"
   />
  );
};

export default Header;
